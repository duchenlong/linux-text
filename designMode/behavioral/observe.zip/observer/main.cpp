#include "head.hpp"

int main() {
    slove();
    return 0;
}
