#include "head.hpp"

int main() {
    slove('A');
    slove('B');
    return 0;
}
